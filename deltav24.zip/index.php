<?php
include "backend/server.php";

?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/jpeg" href="icon.jpg">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>XnetAdelV24</title>
<style>
    :root{--bg:#000000;--fg:#ff0000}
    html,body{height:100%;margin:0}

    body{
    font-family:ui-sans-serif,system-ui,Segoe UI,Roboto,'Helvetica Neue',Arial;
    background:url('jpg/wallpaper.jpg');
    background-repeat: no-repeat;
    background-size:cover;
    color:var(--fg);
    display:flex;
    align-items:center;
    justify-content:center;
    padding-bottom:120px; /* ruang untuk music bar */
    }

    .card{width:920px;max-width:96%;
    background: transparent;
    box-shadow:none;
    border-radius:12px;
    padding:18px;position:relative;z-index:1}

/* animated red border around the card */
.card::before{
    content:"";
    position:absolute;
    inset:-4px; /* space for the border */
    border-radius:16px;
    background:transparent;
    background-size:300% 100%;
    z-index:0;
    animation: border-move 3s linear infinite;
    -webkit-mask: ox, redt;
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    padding:4px;
}

@keyframes border-move{
    from{background-position:0%}
    to{background-position:100%}
}

.header{
display:flex;
align-items:center;
gap:12px;
margin-bottom:12px;
position:relative;z-index:1
}

.logo{width:44px;height:44px;border-radius:8px;background:#000000;border:2px solid #ff0000;display:flex;align-items:center;justify-content:center;color:var(--fg);font-weight:700}
h1{font-size:18px;margin:0;color:var(--fg)}
p.sub{margin:0;color:var(--fg);opacity:0.9;font-size:13px}

.terminal{background:transparent;color:var(--fg);padding:12px;border-radius:8px;height:360px;overflow:auto;font-family:monospace;font-size:13px;line-height:1.4;border:2px solid transparent;position:relative;z-index:1}
.prompt{display:flex;gap:8px;align-items:center;margin-top:10px;position:relative;z-index:1}
.prompt .prompt-text{font-family:monospace;background:#000000;padding:8px 10px;border-radius:8px;color:var(--fg);flex:1;border:1px solid #ff0000}
.btn{background:#ff0000;color:#000000;padding:8px 12px;border-radius:8px;border:2px solid #ff0000;cursor:pointer;font-weight:600}
.btn:disabled{opacity:0.6;cursor:not-allowed}
.controls{display:flex;gap:8px;align-items:center}
.small{font-size:12px;color:var(--fg);opacity:0.9}
.stderr{color:#ff0000}

/* Ensure nothing uses other colors */
*{box-sizing:border-box}

/* ---------- Music bar styles ---------- */
.music-bar {
  position: fixed;
  left: 12px;
  right: 12px;
  bottom: 12px;
  background: rgba(0,0,0,0.6);
  border: 1px solid rgba(255,0,0,0.6);
  padding: 10px;
  border-radius: 12px;
  display:flex;
  align-items:center;
  gap:12px;
  z-index:9999;
  backdrop-filter: blur(6px);
  color:var(--fg);
}

.music-toggle{
  display:flex;
  align-items:center;
  gap:8px;
  cursor:pointer;
  user-select:none;
}

.music-toggle .dot{
  width:36px;height:36px;border-radius:8px;background:#000;border:2px solid #ff0000;display:flex;align-items:center;justify-content:center;font-weight:700;
}

.playlist {
  display:none;
  width:100%;
  max-width:920px;
  background:transparent;
  border-left:1px dashed rgba(255,0,0,0.12);
  padding-left:12px;
  gap:8px;
  align-items:center;
  justify-content:space-between;
}

.playlist.open{display:flex}

.track-list{
  display:flex;
  gap:8px;
  align-items:center;
  overflow:auto;
  padding:4px 0;
}

.track{
  padding:8px 12px;
  border-radius:8px;
  background:rgba(255,255,255,0.02);
  cursor:pointer;
  white-space:nowrap;
  font-size:14px;
  border:1px solid transparent;
}
.track.active{
  background:rgba(255,0,0,0.12);
  border-color:rgba(255,0,0,0.3);
  color:#fff;
}

.music-controls{
  display:flex;
  gap:8px;
  align-items:center;
}

.icon-btn{
  background:transparent;
  border:1px solid rgba(255,0,0,0.25);
  padding:8px;
  border-radius:8px;
  cursor:pointer;
  color:var(--fg);
  font-weight:600;
}

.progress{
  width:160px;
  height:6px;
  background:rgba(255,255,255,0.06);
  border-radius:6px;
  overflow:hidden;
}
.progress > i{
  display:block;
  height:100%;
  width:0%;
  background:rgba(255,0,0,0.9);
}

/* small screens tweak */
@media (max-width:600px){
  .music-bar{flex-direction:column;align-items:flex-start;padding:10px}
  .playlist{width:100%;border-left:none;padding-left:0}
  .progress{width:100%}
}
</style>
</head>
<body>
<div class="card">
    <div class="header">
        <div>
            <h1>XnetDelta V24</h1>
            <p>Dashboard Desain by Adell</p>
        </div>
    </div><div id="terminal" class="terminal" role="log" aria-live="polite">$ ready. press Start to run node all.js</div>
<div class="prompt">
    <div class="prompt-text">/root/Xnet/Adel &gt;</div>
    <div class="controls">
        <button id="startBtn" class="btn">Start</button>
        <button id="stopBtn" class="btn" style="background:#ef4444">Stop</button>
        <div class="small">Status: <span id="status">idle</span></div>
    </div>
</div>
</div>
<div class="music-bar" aria-hidden="false">
  <div class="music-toggle" id="musicToggle" role="button" tabindex="0" aria-pressed="false" title="Toggle playlist">
    <div class="dot">♪</div>
    <div>
      <div style="font-size:14px">Music</div>
      <div class="small" style="opacity:0.8">Klik untuk buka playlist</div>
    </div>
  </div>
  <div class="playlist" id="playlist">
    <div class="track-list" id="trackList" role="list">
    </div>
    <div style="display:flex;align-items:center;gap:8px">
      <div class="music-controls">
        <button id="prevBtn" class="icon-btn" title="Prev">⏮</button>
        <button id="playPauseBtn" class="icon-btn" title="Play/Pause">▶</button>
        <button id="nextBtn" class="icon-btn" title="Next">⏭</button>
      </div>
      <div class="progress" title="progress"><i id="progBar"></i></div>
    </div>
  </div>
  <audio id="audioPlayer" preload="metadata"></audio>
</div>
<script src="javascript/script.js"></script>
<script src="javascript/index.js"></script>
</body>
</html>
