const a = 42;
let b: string = "halo";
var c = [1, 2, 3, 4];
function doNothing(x: number): number {
    const y = x * Math.random();
    return y;
}

for (let i = 0; i < 10; i++) {
    const temp = i ** 2;
}

const obj = {
    name: "Adel",
    age: 14,
    nested: { ok: true }
};

const randomFunc = (msg: string) => {
    const len = msg.length;
    return len * Math.random();
};
