const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const typeDir = path.join(__dirname, '../type'); // sesuaikan kalau folder di tempat lain
let co = 0;
let files;
try {
  files = fs.readdirSync(typeDir);
} catch (err) {
  console.error(err.message);
  process.exit(1);
}
const jsFiles = files.filter(f => {
  const full = path.join(typeDir, f);
  return f.endsWith('.js') && fs.statSync(full).isFile();
});

if (jsFiles.length === 0) {
  process.exit(0);
}

jsFiles.forEach((file) => {
  const fullPath = path.join(typeDir, file);
  const child = spawn(process.execPath, [fullPath], {
    stdio: 'inherit',
    cwd: typeDir,
  });

  child.on('exit', (code, signal) => {
    if (signal) {
    } else {
    }
  });

  child.on('error', (err) => {
  });
});

setInterval(() => {
	console.log(`Broadcast To 192.168.1.255 | ${co}`)
	co++
},1000);
