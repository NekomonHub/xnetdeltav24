(function(){
    const start = document.getElementById('startBtn');
    const stop = document.getElementById('stopBtn');
    const term = document.getElementById('terminal');
    const status = document.getElementById('status');
    let es = null;
    function appendLine(text, isErr){
        const div = document.createElement('div');
        if (isErr) div.className = 'stderr';
        div.textContent = text;
        term.appendChild(div);
        term.scrollTop = term.scrollHeight;
    }   start.addEventListener('click', ()=>{
        if (es) return;
        appendLine('$ Attack Starting...');
        status.textContent = 'running';
        start.disabled = true;
        stop.disabled = false;
        es = new EventSource(window.location.pathname + '?action=stream');
        es.onmessage = function(e){
            if (e.data === '__PROCESS_FINISHED__'){
                appendLine('$ process finished');
                es.close();
                es = null;
                status.textContent = 'idle';
                start.disabled = false;
                stop.disabled = true;
                return;
            }
            if (e.data.startsWith('[ERR]')){
                appendLine(e.data.replace(/ERR\s*/,'(stderr) '), true);
            } else {
                appendLine(e.data);
            }
        };

        es.onerror = function(ev){
            appendLine('$ connection error or closed');
            if (es) es.close();
            es = null;
            status.textContent = 'idle';
            start.disabled = false;
            stop.disabled = true;
        };
    });

    stop.addEventListener('click', ()=>{
        if (!es) return;
        appendLine('$ requested stop (closing stream)');
        es.close();
        es = null;
        status.textContent = 'idle';
        start.disabled = false;
        stop.disabled = true;
    });

    stop.disabled = true;
})();
