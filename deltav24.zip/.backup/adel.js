const { spawn } = require('child_process');
const open = require('open').default;
const adel = require('./case/color.js');
const teks = `
  ............''',,;;;::ccllodkO0K0kxdoollcc::;;,,'''..
............'''',,;;;::cclodo::clccoO0Odollcc::;;,,'''.
...........''',,,;;::ccllod;.........,oKkdolcc::;;,,,''
..........''',,;;;::ccllod,....  .   ..lKxoolcc::;;,,,'
:,''....''',,,;;;::ccllod,.        ..  cKOdoolcc::;;,,'
doc;,;,,,,,,;;;:cccllooo;.        ... .:kkddoolcc::;;,,
xkxo:::::::::ccccllloooc.        .;;'',;xxxddoolcc::;;,
dxxdlcldxkOkxxddlloooo:..       .::clx;dOkkxdddoolcc:::
loddddxkO00KK0Okdoddc...      ..'dkkd;od0OOOkkxxdollllo
cllddddxkkxdodxkOd:....       .';:c0d:kk0OOOOOOkxolooxO
;;;;;;;;;:lxxoc;.....        ...'';cXx00OKKK00Okdooodxx
;;cclccc:,;,'.....          .....'':c0XKKXKKK00Okxxxkkd
::::;,.'''....     .'...  ... ...'::cdXXNXK000OOOOO0KKO
,;;'..'....    ..;:c.............'',:cxKXK0OOOkkOOKXK0k
,........   .,lkk:.. ............'',;:cld00OkkkO0KXKK0O
... .... 'cdkko,..;,   .''.......',''',,cdKXK0KKKXK0Okk
..  .:'.:xdd:....oc,'.  .,;'...........',;:lk0XKKK0OOkx
....:c,,loo'.:;.o;,...';;..'.     ...',,''',;lkX00Okxdd
'...'..coc..dc.,;,'..';kNOo'...   ..'''.','':cxKKOkxxol
;,,':l.c;.'dl..,,'..';oKNko,   .....'.';::cx;;::lo,'...
,,cclo:,.'oo'..,'..',:dKk,...    ...'.,cc,.....',:;;cox
'.;looo;,;c:...''''',ckx;.........',,..lOc,,;:coooolloo
,,'ldxdl,oo;,..,,,'';oo:'.',;:cc::,'. .,:lxollcldkkxooo
;::::ccl:od:l:,codoooodlcc:,'..         ;'dxoooodOK000O
:ccclooolloodooddxxxd;....              .;,xdddxxO0XXXX
ccllodxxxxxxxxdl::cc'.        .........',::okkxdkKKKKK0
ooooolcccloddxkkkdl;... . ....'',',::ccccll:dkdxkkkkxxx
;:;;;,,,,;cooddxxxocl:;..,::c:cc::cooccccccoxO000kxollc
`;

function clear() {
    spawn('clear', { stdio: 'inherit' });
}

function php() {
    const port = Math.floor(Math.random() * (65535 - 1024)) + 1024;
    const server = spawn('php', ['-S', `0.0.0.0:${port}`], { stdio: 'ignore' });

    setTimeout(async () => {
        await open(`http://0.0.0.0:${port}`);
        clear();
        setTimeout(() => console.log(adel.pastelPurple.bold(teks)), 100);
    }, 1000);
}

php();
