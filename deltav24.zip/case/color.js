// file: adel.js
const colors = {
    black: "\x1b[30m",
    red: "\x1b[31m",
    green: "\x1b[32m",
    yellow: "\x1b[33m",
    blue: "\x1b[34m",
    magenta: "\x1b[35m",
    cyan: "\x1b[36m",
    white: "\x1b[37m",
    gray: "\x1b[90m",
    // rare colors
    pink: "\x1b[95m",
    orange: "\x1b[91m",
    teal: "\x1b[96m",
    // pastel cute colors
    pastelPink: "\x1b[38;5;218m",
    pastelPurple: "\x1b[38;5;183m",
    pastelBlue: "\x1b[38;5;153m",
    pastelMint: "\x1b[38;5;159m",
    pastelPeach: "\x1b[38;5;216m",
    pastelYellow: "\x1b[38;5;229m",
};

const styles = {
    bold: "\x1b[1m",
    italic: "\x1b[3m",
    underline: "\x1b[4m",
    inverse: "\x1b[7m",
    reset: "\x1b[0m",
};

// helper untuk chainable
function createProxy(currentStyles = []) {
    return new Proxy(() => {}, {
        get(_, prop) {
            if (colors[prop] || styles[prop]) {
                return createProxy([...currentStyles, prop]);
            }
            return undefined;
        },
        apply(_, __, args) {
            const text = args.join(" ");
            const codes = currentStyles.map(s => colors[s] || styles[s]).join("");
            return `${codes}${text}${styles.reset}`;
        }
    });
}

module.exports = createProxy();
