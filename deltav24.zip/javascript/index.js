(function(){
  const tracks = [
    { title: 'Slay x Enough! - Eternxlkz', src: '../music/sxe.mp3' },
    { title: 'Enough - Eternxlkz', src: '../music/enough.mp3' },
    { title: 'Fragment - Slxughter', src: '../music/fg.mp3' },
    { title: 'Aura - Ogryzek', src: '../music/aura.mp3' },
    { title: 'Dare - Dj Alim', src: '../music/dare.mp3' },
    { title: 'Next! - NCTS', src: '../music/next.mp3' }
  ];

  const audio = document.getElementById('audioPlayer');
  const trackListEl = document.getElementById('trackList');
  const playlistEl = document.getElementById('playlist');
  const toggle = document.getElementById('musicToggle');
  const playPauseBtn = document.getElementById('playPauseBtn');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const progBar = document.getElementById('progBar');
  let current = -1;
  let isPlaying = false;
  tracks.forEach((t, i) => {
    const el = document.createElement('div');
    el.className = 'track';
    el.setAttribute('role','listitem');
    el.textContent = t.title;
    el.dataset.index = i;
    el.addEventListener('click', ()=> playIndex(i));
    trackListEl.appendChild(el);
  });

  function highlight(){
    const nodes = trackListEl.querySelectorAll('.track');
    nodes.forEach(n => n.classList.remove('active'));
    if (current >=0) nodes[current].classList.add('active');
  }

  function playIndex(i){
    if (i < 0 || i >= tracks.length) return;
    const t = tracks[i];
    if (!t.src){
      alert('File lagu tidak ditemukan: ' + t.title);
      return;
    }
    current = i;
    audio.src = t.src;
    audio.play().catch(e=>{
      console.warn('play failed', e);
      isPlaying = false;
      playPauseBtn.textContent = '▶';
    });
    isPlaying = true;
    playPauseBtn.textContent = '⏸';
    highlight();
  }

  function togglePlaylist(){
    const open = playlistEl.classList.toggle('open');
    toggle.setAttribute('aria-pressed', open ? 'true' : 'false');
  }

  function togglePlayPause(){
    if (!audio.src && tracks.length) {
      playIndex(0);
      return;
    }
    if (audio.paused) {
      audio.play();
      isPlaying = true;
      playPauseBtn.textContent = '⏸';
    } else {
      audio.pause();
      isPlaying = false;
      playPauseBtn.textContent = '▶';
    }
  }

  function prev(){
    if (current <= 0) playIndex(tracks.length - 1);
    else playIndex(current - 1);
  }
  function next(){
    if (current >= tracks.length - 1) playIndex(0);
    else playIndex(current + 1);
  }

  toggle.addEventListener('click', togglePlaylist);
  toggle.addEventListener('keypress', (e)=> { if (e.key === 'Enter') togglePlaylist(); });
  playPauseBtn.addEventListener('click', togglePlayPause);
  prevBtn.addEventListener('click', prev);
  nextBtn.addEventListener('click', next);
  audio.addEventListener('ended', ()=> {
    next();
  });

  audio.addEventListener('timeupdate', ()=>{
    if (!audio.duration || isNaN(audio.duration)) return;
    const pct = (audio.currentTime / audio.duration) * 100;
    progBar.style.width = pct + '%';
  });

  const progressWrap = progBar.parentElement;
  progressWrap.addEventListener('click', (e)=>{
    const rect = progressWrap.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const pct = x / rect.width;
    if (audio.duration) audio.currentTime = pct * audio.duration;
  });
  highlight();
  window.addEventListener('keydown', (e)=>{
    if (e.key === ' ' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA'){
      e.preventDefault();
      togglePlayPause();
    } else if (e.key === 'ArrowRight') next();
    else if (e.key === 'ArrowLeft') prev();
  });
})();
