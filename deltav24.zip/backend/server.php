<?php
if (isset($_GET['action']) && $_GET['action'] === 'stream') {
    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');
    set_time_limit(0);
    ignore_user_abort(true);

    $cmd = 'node all.js'; // <-- only run this exact command (no user input) for safety

    $descriptorspec = [
        1 => ['pipe', 'w'], // stdout
        2 => ['pipe', 'w']  // stderr
    ];

    $process = proc_open($cmd, $descriptorspec, $pipes, __DIR__);

    if (!is_resource($process)) {
        echo "data: ERROR: failed to start process\n\n";
        flush();
        exit;
    }

    stream_set_blocking($pipes[1], false);
    stream_set_blocking($pipes[2], false);

    while (true) {
        $status = proc_get_status($process);
        $running = $status['running'];

        $out = '';
        $err = '';

        $o = fgets($pipes[1]);
        while ($o !== false) {
            $out .= $o;
            $o = fgets($pipes[1]);
        }

        $e = fgets($pipes[2]);
        while ($e !== false) {
            $err .= $e;
            $e = fgets($pipes[2]);
        }

        if ($out !== '') {
            $lines = explode("\n", rtrim($out, "\n"));
            foreach ($lines as $line) {
                $safe = str_replace("\r", "", $line);
                echo "data: ".str_replace("\n","\\n", $safe) ."\n\n";
            }
            flush();
        }

        if ($err !== '') {
            $lines = explode("\n", rtrim($err, "\n"));
            foreach ($lines as $line) {
                $safe = str_replace("\r", "", $line);
                echo "data: [ERR] ".str_replace("\n","\\n", $safe) ."\n\n";
            }
            flush();
        }

        if (!$running) break;
        usleep(100000); // 100ms
    }

    while (!feof($pipes[1])) {
        $line = fgets($pipes[1]);
        if ($line !== false) echo "data: ".rtrim($line, "\n")."\n\n";
    }
    while (!feof($pipes[2])) {
        $line = fgets($pipes[2]);
        if ($line !== false) echo "data: [ERR] ".rtrim($line, "\n")."\n\n";
    }

    fclose($pipes[1]);
    fclose($pipes[2]);
    proc_close($process);
    echo "data: __PROCESS_FINISHED__\n\n";
    flush();
    exit;
}

?>
